package com.example.lemonade;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class LemonadeController {

    @FXML
    private ListView<String> CartView;

    @FXML
    private Button LblueLem;

    @FXML
    private Button LbrLem;

    @FXML
    private Button LclasLem;

    @FXML
    private TextField Login;

    @FXML
    private Label totalPrice;


    @FXML
    private Button LrasLem;

    @FXML
    private Button Sbrlem;

    @FXML
    private Button SclasLem;

    @FXML
    private Button SrasLem;

    @FXML
    private Button pinkLlem;

    @FXML
    private Button pinksLem;

    @FXML
    private Button sBlueLem;


    @FXML
    void addLargeBlueRaspToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 5.00));
        CartView.getItems().add("Large Blue-Raspberry Lemonade");
        BRLemonade brLLem = new BRLemonade("Large");


    }

    @FXML
    void addLargeBlueToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 4.36));
        CartView.getItems().add("Large Blue Lemonade");
        BlueberryLemonade bLLem = new BlueberryLemonade("Large");


    }

    @FXML
    void addLargeClassicToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 3.74));
        CartView.getItems().add("Large Classic Lemonade");
        ClasicLemonade clasLLem = new ClasicLemonade("Large");
    }

    @FXML
    void addLargePinkToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 4.36));
        CartView.getItems().add("Large Pink Lemonade");
        PinkLemonade pLlem = new PinkLemonade("Large");

    }

    @FXML
    void addLargeRaspToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 4.36));
        CartView.getItems().add("Large Raspberry Lemonade");
        RaspberryLemonade rasLem = new RaspberryLemonade("Large");
    }

    @FXML
    void addSmallBlueRaspToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 3.00));
        CartView.getItems().add("Small Blue Raspberry Lemonade");
        BRLemonade brSlem = new BRLemonade("Small");


    }

    @FXML
    void addSmallBlueToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 2.62));
        CartView.getItems().add("Small Blue Lemonade");
        BlueberryLemonade sblem = new BlueberryLemonade("Small");

    }

    @FXML
    void addSmallClassicToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 2.24));
        CartView.getItems().add("Small Classic Lemonade");
        ClasicLemonade clasSlem = new ClasicLemonade("Small");

    }

    @FXML
    void addSmallPinkToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 2.62));
        CartView.getItems().add("Small Pink Lemonade");
        PinkLemonade pSlem = new PinkLemonade("Small");

    }

    @FXML
    void addSmallRaspToCart(ActionEvent event) {
        totalPrice.setText(String.valueOf(Double.parseDouble(totalPrice.getText()) + 2.62));
        CartView.getItems().add("Small Raspberry Lemonade");
        RaspberryLemonade rasSlem = new RaspberryLemonade("Small");

    }

    @FXML
    void openEmployeeLogin(ActionEvent event) {

    }

}
