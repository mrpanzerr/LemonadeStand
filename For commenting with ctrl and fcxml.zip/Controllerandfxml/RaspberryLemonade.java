package com.example.lemonade;

public class RaspberryLemonade extends Drink{
    public RaspberryLemonade(String size) {
        super("Raspberry Lemonade", size, 3.49);
        if(this.getSize().equals("Large")){
            Inventory.subtractSugar(3);
            Inventory.subtractLemons(3);
        }
        else if(this.getSize().equals("Small")){
            Inventory.subtractLemons(1);
            Inventory.subtractSugar(1);
        }
        else{
            Inventory.subtractSugar(2);
            Inventory.subtractLemons(2);
        }
    }
}
